
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from .forms import *
from .models import *
import json


@csrf_exempt
@login_required
def home(request):
    info = 'Nothing'
    return render(request, 'app/home.html', {
        'info': info
    })


@csrf_exempt
def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            email = form.cleaned_data['email']
            user = User.objects.create_user(username=username, password=password, email=email)
            login(request, user)
            return redirect(reverse('home'))
    else:
        form = RegisterForm()
    return render(request, 'app/register.html', {
        'form': form,
    })


@csrf_exempt
def my_login(request):
    info = ''  # any additional info shown to user
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect(reverse('home'))
                else:
                    info = 'user disabled.'
            else:
                info = 'invalid password.'
    else:
        form = LoginForm()
    return render(request, 'app/login.html', {
        'form': form,
        'info': info,
    })


@csrf_exempt
@login_required
def upload(request):
    info = 'Nothing'
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            authors = form.cleaned_data['authors']
            keywords = form.cleaned_data['keywords']
            tags = form.cleaned_data['tags']
            profession = form.cleaned_data['profession']
            summary = form.cleaned_data['summary']
            publish_date = form.cleaned_data['publish_date']
            title = form.cleaned_data['title']
            conference = form.cleaned_data['conference']
            file = form.cleaned_data['file']

            aut = []
            valid = True  # Mark: - 减少出口，但是引入了额外的变量。是否有更好的方法？

            # Mark: MacOS和Linux是\r\n
            for aut_name in authors.strip('\r').split('\n'):
                try:
                    aut.append(User.objects.get(username=aut_name))
                except:
                    info = 'User ' + aut_name + ' not found.'
                    valid = False
                    break

            if valid:
                article = Article(publisher=request.user,
                                  keywords=keywords,
                                  tags=tags,
                                  profession=profession,
                                  summary=summary,
                                  publish_date=publish_date,
                                  title=title,
                                  conference=conference,
                                  file=file)
                article.save()
                for a in aut:
                    article.authors.add(a)

                with open('pdf/'+file.name, 'wb') as f:
                    for chunk in file.chunks():
                        f.write(chunk)

                return redirect(reverse('home'))
        else:
            info = 'Please check your input.'
    else:
        form = UploadForm()

    return render(request, 'app/upload.html', {
        'form': form,
        'info': info
    })

@csrf_exempt
@login_required
def search_user(request):
    # email = name = gender = profession = location = phone_number = university =
    username = info = ''
    shown_attr = ['username', 'email']
    shown = []
    if request.method == 'POST':
        form = SearchUserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            user = User.objects.filter(username = username)
            if user:
                info = 'User found，information shown below:'
                user = user[0]
                shown = [(key, user.__dict__[key]) for key in shown_attr]
                # username = user.username
                # email = user.email
                # name = user.name
                # gender = user.gender
                # profession = user.profession
                # location = user.location
                # phone_number = user.phone_number
                # university = user.university

            else:
                info = 'User not exist'
    else:
        form = SearchUserForm()

    return render(request, 'app/search_user.html', {
        'form': form,
        'shown': shown,
        'info': info,
        'username': username
        # 'email': email,
        # 'name': name,
        # 'gender': gender,
        # 'profession': profession,
        # 'location': location,
        # 'phone_number': phone_number,
        # 'university': university,
    })

@csrf_exempt
@login_required
def add_friend(request):
    info = ''
    if request.method == 'POST':
        # get information
        user = request.user
        friendName = request.POST['friend']
        friend = User.objects.filter(username=friendName)
        friend = friend[0]

        # check
        if friendName == user.username:
            return redirect(reverse('search_user'), {'info': ''})
        frdLst = user.friends
        tmp = Friends.objects.filter(user=user, friend=friend)
        if tmp:
            return redirect(reverse('search_user'), {'info': 'Already your friend'})

        # insert in Message and MessageList
        if not hasattr(friend, 'messageList'):
            messageList = MessageList(user=friend)
            messageList.save()
        msgLst = friend.messageList
        msg = Message(type='add_friend', content=user.username+' applies for adding you as a friend.', sender=user)
        # tmp = Message.objects.filter(content=user.username+' applies for adding you as a friend.', state=True, )
        repeat = False
        for m in msgLst.messages.all():
            if m.content == msg.content:
                repeat = True
                break
        if not repeat:
            msg.save()
            msgLst.save()
            msgLst.messages.add(msg)

        info = 'Friend request sent successfully'
    else:
        return redirect(reverse('search_user'))
    return render(request, 'app/home.html', {'info': info})


@csrf_exempt
@login_required
def show_friends(request):
    user = request.user
    frdLst = user.friends.all()
    return render(request, 'app/show_friends.html', {'frdLst': frdLst})


@csrf_exempt
@login_required
def check_messages(request):
    user = request.user
    if not hasattr(user, 'messageList'):
        messageList = MessageList(user=user)
        messageList.save()
    msgLst = user.messageList
    messages = msgLst.messages.all()
    return render(request, 'app/check_messages.html', {'messages': messages})


@csrf_exempt
@login_required
def delete_message(request):
    data = json.loads(request.body.decode('utf-8'))
    messageId = data['messageId']
    Message.objects.filter(id=messageId).delete()
    user = request.user
    msgLst = user.messageList
    messages = msgLst.messages.all()
    return render(request, 'app/check_messages.html', {'messages': messages})


@csrf_exempt
@login_required
def delete_friend(request):
    data = json.loads(request.body.decode('utf-8'))
    # get json data
    friendName = data['friendName']
    user = request.user
    friend = User.objects.filter(username=friendName)
    friend = friend[0]
    # delete from Friends
    Friends.objects.filter(user=user, friend=friend).delete()
    Friends.objects.filter(user=friend, friend=user).delete()
    msgLst = friend.messageList
    msg = Message(type='delete_friend', content=user.username+' has delete you from his friend list.', sender=user)
    msg.save()
    msgLst.save()
    msgLst.messages.add(msg)
    # send a message
    return render(request, 'app/home.html', {'info': 'Nothing'})


@csrf_exempt
@login_required
def add_friend_reply(request):
    data = json.loads(request.body.decode('utf-8'))
    # get json data
    action = data['action']
    messageId = data['messageId']
    friendName = data['friendName']
    Message.objects.filter(id=messageId).update(state=False)
    user = request.user
    friend = User.objects.filter(username=friendName)
    friend = friend[0]
    # accept
    if action == 'accept':
        # insert in Friends
        tmp = Friends.objects.filter(user=user, friend=friend)
        if not tmp:
            if hasattr(user, 'friends'):
                tuple = Friends(user=user, friend=friend)
                tuple.save()
                frdLst = user.friends
                frdLst.add(tuple)
            if hasattr(friend, 'friends'):
                tuple = Friends(user=friend, friend=user)
                tuple.save()
                frdLst = friend.friends
                frdLst.add(tuple)
        # insert in Message and MessageList
        if not hasattr(friend, 'messageList'):
            messageList = MessageList(user=friend)
            messageList.save()
        msgLst = friend.messageList
        msg = Message(type='add_friend_reply', content=user.username+' has agreed your friend request.', sender=user)
        msg.save()
        msgLst.save()
        msgLst.messages.add(msg)
    # refuse
    elif action == 'reject':
        # insert in Message and MessageList
        if not hasattr(friend, 'messageList'):
            messageList = MessageList(user=friend)
            messageList.save()
        msgLst = friend.messageList
        msg = Message(type='add_friend_reply', content=user.username+' has reject your friend request.', sender=user)
        msg.save()
        msgLst.save()
        msgLst.messages.add(msg)
    return render(request, 'app/home.html', {'info': 'Nothing'})


@csrf_exempt
@login_required
def confirm_message(request):
    data = json.loads(request.body.decode('utf-8'))
    messageId = data['messageId']
    Message.objects.filter(id=messageId).update(state=False)
    return render(request, 'app/home.html', {'info': 'Nothing'})


@csrf_exempt
@login_required
def pdf_view(request):
    return render(request, 'app/pdf_view.html')


@csrf_exempt
@login_required
def create_group(request):
    return render(request, 'app/create_group.html')


@csrf_exempt
@login_required
def show_groups(request):
    return render(request, 'app/show_groups.html')