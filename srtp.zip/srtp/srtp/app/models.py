import time

from datetime import datetime
from django.contrib.auth.models import AbstractUser
from django.db import models


class JsonField(models.TextField):
    pass


class User(AbstractUser):
    name = models.CharField(max_length=50)
    gender = models.CharField(max_length=8, default='unknown')
    birthday = models.DateTimeField(default=datetime(1997, 1, 1))
    profession = models.CharField(max_length=50, default='unknown')
    resume = models.TextField(default='')
    location = models.CharField(max_length=50, default='unknown')
    tags = JsonField(default='')
    phone_number = models.CharField(max_length=20, default='unknown')
    university = models.CharField(max_length=50, default='unknown')
    created_date = models.DateTimeField(auto_now_add=True)

    @property
    def age(self):
        localtime = time.localtime(time.time())
        return localtime.tm_year - self.birthday.year

    def __str__(self):
        return "User " + self.username + ' (' + self.first_name + ' ' + self.last_name + ')'


class Article(models.Model):
    publisher = models.ForeignKey(User, on_delete=models.CASCADE, related_name='published_articles')
    authors = models.ManyToManyField(User, related_name='articles')
    keywords = JsonField(default='')
    tags = JsonField(default='')
    profession = models.CharField(max_length=50, default='others')
    summary = models.TextField(default='None')
    upload_date = models.DateTimeField(auto_now_add=True)  # the date when article is UPLOADED to the WEBSITE
    publish_date = models.DateTimeField()  # the date when article is PUBLISHED by AUTHORS
    title = models.CharField(max_length=255)
    conference = models.CharField(max_length=255, default='None')
    file = models.FileField(upload_to='./pdf/')

    def __str__(self):
        return "Article " + self.title


class Friends(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="friends")
    friend = models.ForeignKey(User, on_delete=models.CASCADE, related_name="other")

class Message(models.Model):
    type = models.CharField(max_length=20)
    content = models.CharField(max_length=200)
    date = models.DateTimeField(auto_now_add=True)
    state = models.BooleanField(default=True)
    sender = models.ForeignKey(User, on_delete=models.CASCADE)

class MessageList(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True, related_name='messageList') #messageList相当于MessageList一个实例
    messages = models.ManyToManyField(Message)


class GroupMember(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)

class Group(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True, related_name='group')
    groupMembers = models.ManyToManyField(GroupMember)







