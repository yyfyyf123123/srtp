//function ConveyData(data){
//    alert(data);
//    var form = document.getElementById('delete_message');
//    form.messageId.value = 'data';
//}

function ConveyJsonData(jsonData, url){
    // alert(JSON.stringify(jsonData))
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=UTF-8",
        data: JSON.stringify(jsonData),
        success: function() {}
    });
    location.reload();
}