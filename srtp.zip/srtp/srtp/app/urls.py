from django.conf.urls import url

from app import views

urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^register$', views.register, name='register'),
    url(r'^login$', views.my_login, name='login'),
    url(r'^upload$', views.upload, name='upload'),
    url(r'^search_user$', views.search_user, name='search_user'),
    url(r'^add_friend$', views.add_friend, name='add_friend'),
    url(r'^show_friends$', views.show_friends, name='show_friends'),
    url(r'^check_messages$', views.check_messages, name='check_messages'),
    url(r'^delete_message$', views.delete_message, name='delete_message'),
    url(r'^add_friend_reply$', views.add_friend_reply, name='add_friend_reply'),
    url(r'^confirm_message$', views.confirm_message, name='confirm_message'),
    url(r'^delete_friend$', views.delete_friend, name='delete_friend'),
    url(r'^pdf_view$', views.pdf_view, name='pdf_view'),
    url(r'^create_group$', views.create_group, name='create_group'),
    url(r'^show_groups$', views.show_groups, name='show_groups')
]

