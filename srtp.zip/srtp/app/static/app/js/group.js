var groupName;
function setGroupName(name){
    groupName = name;
}

function getGroupName(){
    return groupName;
}