function AddFriendInput(friendName){
    var form = document.getElementById('add_friend');
    form.friend.value = friendName;
    alert(friendName);
}