var con, rs;

function ConnectDB(){
	con = new ActiveXObject("ADODB.Connection");
	var connectionstring = "Driver={MySQL ODBC 5.1 Driver}; Server=localhost; Database=srtp; User=root; Password=yy81004522; Option=3; Port=3306"; 
	con.open(connectionstring);
	return con;
}

function CloseDB(){
	if(rs != null) { 
        rs.close(); 
        rs = null; 
    } 
    if(con != null) { 
        con.close(); 
        con = null; 
    } 
}

//insert or delete
function ExecuteUpdate(sql) { 
    ConnectDB(); 
    try { 
        con.execute(sql); 
        return true; 
    } catch (e) { 
        document.write(e.description); 
    } finally { 
        CloseDB(); 
    } 
    return false; 
} 

function ExecuteQuery(sql){
	ConnectDB();
	try{

	} catch (e) { 
        document.write(e.description); 
    } finally { 
        CloseDB(); 
    } 
}