from django.conf.urls import url

from app import views

urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^register$', views.register, name='register'),
    url(r'^login$', views.my_login, name='login'),
    url(r'^upload$', views.upload, name='upload'),
    url(r'^search_user$', views.search_user, name='search_user'),
    url(r'^add_friend$', views.add_friend, name='add_friend'),
    url(r'^show_friends$', views.show_friends, name='show_friends'),
    url(r'^check_messages$', views.check_messages, name='check_messages'),
    url(r'^delete_message$', views.delete_message, name='delete_message'),
    url(r'^add_friend_reply$', views.add_friend_reply, name='add_friend_reply'),
    url(r'^confirm_message$', views.confirm_message, name='confirm_message'),
    url(r'^delete_friend$', views.delete_friend, name='delete_friend'),
    url(r'^pdf_view$', views.pdf_view, name='pdf_view'),
    url(r'^create_group$', views.create_group, name='create_group'),
    url(r'^show_groups$', views.show_groups, name='show_groups'),
    url(r'^invite_group$', views.invite_group, name='invite_group'),
    url(r'^invite_group_reply$', views.invite_group_reply, name='invite_group_reply'),
    url(r'^delete_gm$', views.delete_gm, name='delete_gm'),
    url(r'^delete_group$', views.delete_group, name='delete_group'),
    url(r'^quit_group$', views.quit_group, name='quit_group'),
    url(r'^create_work$', views.create_work, name='create_work'),
    url(r'^delete_work$', views.delete_work, name='delete_work'),
    url(r'^add_new_version$', views.add_new_version, name='add_new_version'),
    url(r'^add_new_version_submit$', views.add_new_version_submit, name='add_new_version_submit'),
    url(r'^view_version$', views.view_version, name='view_version'),
    url(r'^view_version_pdf$', views.view_version_pdf, name='view_version_pdf')
]

