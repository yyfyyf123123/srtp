from datetime import datetime

from django import forms
from .models import *


class RegisterForm(forms.Form):
    username = forms.CharField(min_length=6, max_length=20, required=True)
    password = forms.CharField(min_length=6, max_length=20, required=True)
    password2 = forms.CharField(min_length=6, max_length=20, required=True, label='confirm password')
    email = forms.EmailField(required=False)

    # check whether $password is the same with $password2
    def clean_password2(self):
        password = self.cleaned_data['password']
        password2 = self.cleaned_data['password2']
        if password and password2 and password != password2:
            raise forms.ValidationError('Passwords should be consistent.')
        return password2


class UserDataForm(forms.ModelForm):

    class Meta:
        model = User
        fields = []


class LoginForm(forms.Form):
    username = forms.CharField(min_length=6, max_length=20, required=True)
    password = forms.CharField(min_length=6, max_length=20, required=True, widget=forms.PasswordInput)


class UploadForm(forms.Form):
    file = forms.FileField()
    title = forms.CharField(max_length=255, required=True)
    authors = forms.CharField(max_length=255, widget=forms.Textarea, help_text='each line for one author', required=True)
    summary = forms.CharField(widget=forms.Textarea, required=True)
    keywords = forms.CharField(max_length=255, widget=forms.Textarea, help_text='each line for one keyword', required=False)
    publish_date = forms.DateTimeField(widget=forms.SelectDateWidget(years=[str(yr) for yr in range(1900, datetime.now().year+1)]),
                                       required=True)
    profession = forms.CharField(max_length=50, required=False)
    tags = forms.CharField(max_length=255, widget=forms.Textarea, help_text='each line for one tag', required=False)
    conference = forms.CharField(max_length=255, required=False)


class SearchUserForm(forms.Form):
    username = forms.CharField(min_length=6, max_length=20, required=True)


class CreateGroupForm(forms.Form):
    groupName = forms.CharField(min_length=1, max_length=50, required=True)


class CreateWorkForm(forms.Form):
    workName = forms.CharField(min_length=1, max_length=50, required=True)


class AddNewVersionForm(forms.Form):
    file = forms.FileField()
    remark = forms.CharField(max_length=255, required=True)




